package com.dooapp.fxform.reflection.classcast;

/**
 * A device model use for testing.
 * <br>
 * Created at 13/12/13 16:59.<br>
 *
 * @author Bastien
 */
public class DeviceModel {

}
