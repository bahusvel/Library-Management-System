package com.dooapp.fxform;

import java.util.ResourceBundle;

/**
 * TODO write documentation<br>
 * <br>
 * Created at 27/03/14 17:17.<br>
 *
 * @author Bastien
 */
public class Utils {
    public static ResourceBundle SAMPLE = ResourceBundle.getBundle("sample");


}
